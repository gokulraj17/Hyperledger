module.exports = {
	entry: "./dist/ByteBufferAB.js"
};
