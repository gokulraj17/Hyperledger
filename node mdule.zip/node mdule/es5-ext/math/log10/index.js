'use strict';

module.exports = require('./is-implemented')()
	? Math.log10
	: require('./shim');
