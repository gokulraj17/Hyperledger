'use strict';

module.exports = new Function("return this")();
