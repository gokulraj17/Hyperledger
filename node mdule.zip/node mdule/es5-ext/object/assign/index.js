'use strict';

module.exports = require('./is-implemented')()
	? Object.assign
	: require('./shim');
